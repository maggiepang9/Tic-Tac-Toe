//create variables for the scores, current player, and conditions for winning the game
let currentPlayer = 'X';
let xScore = 0;
let oScore = 0;
let conditions = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]
];
const squares = document.querySelectorAll('.square');
const resetButton = document.querySelector('.btn');
let board = ['', '', '', '', '', '', '', '', ''];
let result = document.querySelector('.result');

//const for filling in the board on click and switching to the next player
const ticTacToe = (element, index) => {
    element.value = currentPlayer;
    element.disabled = true;
    board[index] = currentPlayer;
    currentPlayer = currentPlayer == 'X' ? 'O' : 'X';
    result.innerHTML = `${currentPlayer}'s' Turn`;

  //for loop to run through the board and check if someone has achieved one of the winnning conditions
    for (let i = 0; i < conditions.length; i++) {
        let condition = conditions[i];
        let a = board[condition[0]];
        let b = board[condition[1]];
        let c = board[condition[2]];
      //continue if someone has not won
        if (a == '' || b == '' || c == '') {
            continue;
        }
        if ((a == b) && (b == c) && (a==c)) {
          //add a point for x and change text to x won if current player is o
          if(currentPlayer == 'O'){
            squares.forEach((square) => square.disabled = true);
            xScore++;
            document.getElementById("xScore").value = xScore;
            result.innerHTML = `X Won!`;
          }
          //add a point for o and change text to o won if current player is x
          else if(currentPlayer == 'X'){
            squares.forEach((square) => square.disabled = true);
            oScore++;
            document.getElementById("oScore").value = oScore;
            result.innerHTML = `O Won!`;   
          }         
          //disable the squares so that they do not input onclick anymore
        squares.forEach((square) => square.disabled = true);
        }
      //disable the squares and print that it is a tie if all the squares are filled
      else if ((a != b) || (b != c) || (a!=c)) {
        if (board.every(square => square !== '')){
        result.innerHTML = `It's a Tie!`;
        squares.forEach((square) => square.disabled = true);
        }
        };       
      }
    };
//reset the board but not the points if the play again button is clicked
function playAgain() {
    board = ['', '', '', '', '', '', '', '', ''];
    squares.forEach((square) => {
        square.value = '';
    });
    currentPlayer = 'X';
    result.innerHTML = `X's Turn`;
    squares.forEach((square) => square.disabled = false);  
}

document.querySelector('#playAgain').addEventListener('click', playAgain);

//reset the board and the points if the reset scores button is clicked
function reset() {
    board = ['', '', '', '', '', '', '', '', ''];
    squares.forEach((square) => {
        square.value = '';
    });
    currentPlayer = 'X';
    result.innerHTML = `X's Turn`;
    squares.forEach((square) => square.disabled = false);
    xScore = 0;
    oScore = 0;
    document.getElementById("xScore").value = xScore;
    document.getElementById("oScore").value = oScore;
};

document.querySelector('#reset').addEventListener('click', reset);
squares.forEach((square, i) => {
    square.addEventListener('click', () => ticTacToe(square, i));
});